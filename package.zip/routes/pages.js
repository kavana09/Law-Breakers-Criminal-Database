const express = require('express');
const authController = require('../controllers/auth');
const mysql = require('mysql');
const async = require('hbs/lib/async');
const { promisify } = require('util');
const jwt = require('jsonwebtoken');
const { Console } = require('console');


const router = express.Router();

const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

router.get('/', authController.isLoggedIn,(req, res) => {
    if( req.user ) {
        //console.log(req.user.id);
        db.query('SELECT * FROM complaint WHERE victim_id = ?', [req.user.id], (err, rows) => {
            res.render('index', {
                user: req.user, rows 
            });
        })
        
    } else {
        res.render('index', {
            user: req.user
        });
    }
});

router.get('/register', (req, res) => {
    res.render('register');
});

router.get('/login', (req, res) => {
    res.render('login');
})

router.get('/profile', authController.isLoggedIn, (req, res) => {

    if( req.user ) {
        //console.log(req.user.id);
        db.query('SELECT * FROM complaint WHERE victim_id = ?', [req.user.id], (err, rows) => {
            res.render('profile', {
                user: req.user, rows 
            });
        })
        
    } else {
        res.redirect('/login');
    }
    
})

router.get('/registercomplaint', authController.isLoggedIn, (req, res) => {

    if( req.user) {
        res.render('registercomplaint');
    } else {
        res.redirect('/login');
    }
})

router.post('/registercomplaint', async (req, res) => {
    //console.log(req.cookies.jwt);
    const decoded = await promisify(jwt.verify)(req.cookies.jwt,
        process.env.JWT_SECRET
        );
    console.log(decoded.id);
    const {first_name, last_name, place, description} = req.body;
    db.query('INSERT INTO complaint SET first_name = ?, last_name = ?,place = ?,description = ?, victim_id = ?', [first_name, last_name,place,description,decoded.id], (err, rows) => {
        if(err) {
            console.log(err);
        } else {
            console.log(rows);
            res.render('registercomplaint',{
                message: 'Complaint registered successfully'
            });
        }
    })

})

module.exports = router;